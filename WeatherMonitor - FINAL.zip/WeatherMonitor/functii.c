#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

//SERVER USER

int verif(char * username, char * password) {
	FILE * f = NULL;
	char * line = NULL;
	size_t length = 0;
	int count = 1;
	char vect[2];
	char * user;
	char * pass;

	f = fopen("/home/leafy/Retele/WeatherMonitor/login", "r");
	if (f == NULL) {
		perror("Eroare la deschiderea fisierului.\n");
		return errno;
	}

	while ((getline(&line, &length, f)) != EOF) {
		user = strtok(line, " ");
		pass = strtok(NULL, " ");
		if (strcmp(user, username) == 0 && strcmp(pass, password) == 10) return 1;
		/* VERIFICARI
		* printf("Line %d : %s", count, line);
		* count+=1;
		* printf("Username : %s ", user);
		* printf("Password: %s ", pass);
		* printf("l_u, %zu , l_p , %zu",strlen(user),strlen(pass));
		* printf("Verif : %d %d \n",strcmp(user,username),strcmp(pass, password));
		*/
	}
	fclose(f);
	return 0;
}

int verifUser(char * username) {
	FILE * f = NULL;
	char * line = NULL;
	size_t length = 0;
	char * user;

	f = fopen("/home/leafy/Retele/WeatherMonitor/login", "r");
	if (f == NULL) {
		perror("Eroare la deschiderea fisierului.\n");
		return errno;
	}

	while ((getline(&line, &length, f)) != EOF) {
		user = strtok(line, " ");
		if (strcmp(user, username) == 0) return 1;
	}
	fclose(f);
	return 0;
}

int createAccount(char * username, char * password) {
	FILE * f = NULL;
	FILE * f2 = NULL;
    FILE * f3 = NULL;

	if (verifUser(username) == 1 || username == NULL || password == NULL) return 0;
	else {
		f = fopen("/home/leafy/Retele/WeatherMonitor/login", "a");
		if (f == NULL) {
			perror("Eroare la deschiderea fisierului de login.\n");
			return errno;
		}

		f2 = fopen("/home/leafy/Retele/WeatherMonitor/Users", "a");
		if (f == NULL) {
			perror("Eroare la deschiderea fisierului cu utilizatori.\n");
			return errno;
		}

		char instr[1000] = "touch /home/leafy/Retele/WeatherMonitor/userfiles/";
		strcat(instr, username);
		system(instr);

        char path[200];
        bzero(path,200);
        strcat(path,"/home/leafy/Retele/WeatherMonitor/userfiles/");
        strcat(path,username);

        f3 = fopen(path,"w");
        fprintf(f3,"nimic");
        fclose(f3);
		fprintf(f, "%s %s\n", username, password);
		//fprintf(f2,"%s:: \n", username);

		fclose(f);
		fclose(f2);
		return 1;
	}
}

int addTown(char * user, char * town) {

	FILE * f = NULL;
	FILE * f2 = NULL;
	char * line = NULL;
	char * line2 = NULL;
	size_t length = 0;
	size_t length2 = 0;
	char path[1000];
	int flag1 = 0, flag2 = 0,c=0;

	bzero(path, 1000);
	strcat(path, "/home/leafy/Retele/WeatherMonitor/userfiles/");
	strcat(path, user);

	f = fopen(path, "r+");
	if (f == NULL) {
		perror("Eroare la deschiderea fisierului.\n");
		return errno;
	}

    while ((getline(&line, &length, f)) != EOF) {
        if(strcmp(line,"nimic")==0) c++;
    }
    if (c==1) {
        fclose(f);
        f = fopen(path, "w");
        
        fclose(f);
        f = fopen(path, "r+");
	    if (f == NULL) {
		    perror("Eroare la deschiderea fisierului.\n");
		    return errno;
	    }
    }
	f2 = fopen("/home/leafy/Retele/WeatherMonitor/cities/index", "r");
	if (f2 == NULL) {
		perror("Eroare la deschiderea fisierului.\n");
		return errno;
	}

	while ((getline(&line, &length, f)) != EOF) {
		line[strcspn(line, "\r\n")] = 0;
		if (strcmp(town, line) == 0) flag1 = 1;
	}

	while ((getline(&line2, &length2, f2)) != EOF) {
		line2[strcspn(line2, "\r\n")] = 0;
		if (strcmp(town, line2) == 0) flag2 = 1;
	}

	if (flag2 == 0) return 0;

	if (flag1 == 0) fprintf(f, "%s\n", town);

	fclose(f);
	fclose(f2);
	return 1;
}

int eraseTown(char * user, char * town) {
	FILE * f = NULL;
	FILE * f2 = NULL;
	char * line = NULL;
	char * line2 = NULL;
	size_t length = 0;
	size_t length2 = 0;
	char path[1000];
	char buffer[500] = " ";

	bzero(path, 1000);
	strcat(path, "/home/leafy/Retele/WeatherMonitor/userfiles/");
	strcat(path, user);

	f = fopen(path, "r");
	if (f == NULL) {
		perror("Eroare la deschiderea fisierului.\n");
		return errno;
	}

	f2 = fopen("/home/leafy/Retele/WeatherMonitor/cities/index", "r");
	if (f2 == NULL) {
		perror("Eroare la deschiderea fisierului.\n");
		return errno;
	}

	bzero(buffer, 500);
	while (getline(&line, &length, f) != EOF) {
		line[strcspn(line, "\r\n")] = 0;
		if (strcmp(town, line) != 0) {
			strcat(buffer, line);
			strcat(buffer, "\n");
		}
	}

	fclose(f);

	f = fopen(path, "w");
	if (f == NULL) {
		perror("Eroare la deschiderea fisierului.\n");
		return errno;
	}

	fprintf(f, "%s", buffer);

	fclose(f);
	fclose(f2);
	return 1;
}

char * showWeather(char * user, char * buffer){
    
    FILE *f;
    char * line;
    size_t length;
    char path[100];
    int j = 0, count = 0;
    

    bzero(path,100);
    strcat(path,"/home/leafy/Retele/WeatherMonitor/userfiles/");
    strcat(path,user);

    f = fopen(path,"r");
    
    while(getline(&line,&length,f)!=EOF){
        count++;
    }

    char vect[count][10];

	for (int i = 0; i<count; i++) {
		bzero(vect[i], 10);
	}

	rewind(f);
	while (getline(&line, &length, f) != EOF) {
		line = strtok(line, "\n");
		strcpy(vect[j], line);
		j++;
	}

    /*for(int i=0;i<count;i++){
		printf("%s\n",vect[i]);
	}PANA AICI MERGE*/
    fclose(f);

    for(int i =0; i<count; i++){
        FILE *f2;
        char * line2;
        size_t length2;
        char path2[100];

        bzero(path2,100);
        strcat(path2,"/home/leafy/Retele/WeatherMonitor/cities/");
        strcat(path2,vect[i]);
        //printf("%s\n",path2);
        f2 = fopen(path2,"r");
        
        
        while(getline(&line2,&length2,f2)!=EOF){
            //printf("%s",line2);
            //line = strtok(line, "\n");
            strcat(buffer,line2);            
        }
        if(i!=count-1) strcat(buffer,"\n");
        fclose(f2);
       // printf("===%s",buffer);
    }
    //printf("%s",buffer);
    return buffer;
}

//SERVER ADMIN

int addT(char * town){
    FILE *f;
    char path[100];
    char buff[100];

    char city[20];
    bzero(city,20);
    strcpy(city,strtok(town,"\n"));
    
    int i =0;
    while( city[i] ) {
      tolower(city[i]);
      i++;
    }
    city[0]=toupper(city[0]);


    bzero(buff,100);
    bzero(path,100);
    strcat(path,"/home/leafy/Retele/WeatherMonitor/cities/index");
    f = fopen(path,"a");
    
    strcat(buff,town);
    strcat(buff,"\n");
    

    fprintf(f,"%s",buff);
    fclose(f);
    bzero(path,100);
    strcat(path, "/home/leafy/Retele/WeatherMonitor/cities/");
    strcat(path,town);
    f = fopen(path,"w");
    fclose(f);   
}

int modifT(char * town,char * degrees, char * cond, char * chance){
    FILE *f;
    char path[100];
    char buffer[1000];
    bzero(buffer,1000);
    bzero(path,100);
    strcat(path,"/home/leafy/Retele/WeatherMonitor/cities/");
    strcat(path,town);
    
    f = fopen(path,"r");

    char city[20];
    bzero(city,20);
    strcpy(city,town);
    int i =0;
    while( city[i] ) {
      tolower(city[i]);
      i++;
   }
    city[0]=toupper(city[0]);

    strcat(buffer,"Town: ");
    strcat(buffer,city);
    strcat(buffer,"\nTemperature: ");
    strcat(buffer,degrees);
    strcat(buffer,"℃ \n");
    strcat(buffer,"Sky condition: ");
    strcat(buffer,cond);
    strcat(buffer,"\nPrecipitation chance: ");
    strcat(buffer,chance);
    strcat(buffer,"%");

    fclose(f);
    f = fopen(path,"w");

    fprintf(f,"%s",buffer);
    fclose(f);
    
}

int delTU(char * town){
    FILE * f = NULL;
	char * line = NULL;
    char * line2 = NULL;
    int count=0;
	size_t length = 0;
	size_t length2 = 0;
    char buff[1000];
    char * tok;
    bzero(buff,1000);
    int j=0;
    char path[200];
    char buff2[1000];
    bzero(buff2,1000);
    int flag =0;
    

	f = fopen("/home/leafy/Retele/WeatherMonitor/login", "r");
	if (f == NULL) {
		perror("Eroare la deschiderea fisierului.\n");
		return errno;
	}

    while ((getline(&line, &length, f)) != EOF) {
        if(strcmp(line," \n")!=0 && strcmp(line,"\n")!=0 && strcmp(line," ")!=0 && line!=NULL && strcmp(line,"\0")!=0){
            count++;
        }
    }

    rewind(f);
    char vect[count][10];
    for(int i =0 ;i<count;i++){
        bzero(vect[i],10);
    }

    while ((getline(&line, &length, f)) != EOF) {
        if(strcmp(line,"\n")!=0 && line!=NULL && strcmp(line,"\0")!=0){
            tok = strtok(line," ");
            strcpy(vect[j],tok);
            j++;
            
        }
        
    }
    
    for(int i=0;i<count;i++){
        printf("%s\n",vect[i]);
    }
    fclose(f);
    for(int i=0;i<count-4;i++){
        flag =0;
        bzero(path,200);
        strcat(path,"/home/leafy/Retele/WeatherMonitor/userfiles/");
        strcat(path,vect[i]);
        //printf("%s\n",path);
        f = fopen(path,"r");
        bzero(buff2,1000);
        while ((getline(&line2, &length2, f)) != EOF) {
            //tok = strtok(line2,"\n");
           
            if(strcmp(line2,town)!=10){
                strcat(buff2,line2);
            }
            flag++;
        }
        fclose(f);
    if (flag>0){
        f = fopen(path,"w");
        fprintf(f,"%s",buff2);
        fclose(f);}
        
        //printf("==");
    }
    return 1;
}

int delTC(char * town){
    FILE * f = NULL;
	char * line = NULL;
    int count=0;
	size_t length = 0;
	char buff[1000];
    bzero(buff,1000);

	f = fopen("/home/leafy/Retele/WeatherMonitor/cities/index", "r");
	if (f == NULL) {
		perror("Eroare la deschiderea fisierului.\n");
		return errno;
	}

	while ((getline(&line, &length, f)) != EOF) {
        if(strcmp(line,town)==10)count++;
		if(strcmp(line,town)!=10) strcat(buff,line);
	}

    //printf("%s",buff);
    fclose(f);

	//line2[strcspn(line2, "\r\n")] = 0;

	f = fopen("/home/leafy/Retele/WeatherMonitor/cities/index", "w");
	if (f == NULL) {
		perror("Eroare la deschiderea fisierului.\n");
		return errno;
	}	

	fprintf(f,"%s",buff);

	fclose(f);
	
    char path[100];
    bzero(path,100);
    strcat(path,"rm /home/leafy/Retele/WeatherMonitor/cities/");
    strcat(path,town);
    if(count>0) system(path);
    delTU(town);

	return 1;
    


}

