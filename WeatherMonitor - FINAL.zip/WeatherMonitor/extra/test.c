#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define PORT 2031

extern int errno;
/*
int verif(char * username, char * password){
    FILE * f = NULL;
    char * line = NULL;
    size_t length = 0;
    int count = 1;
    char vect[2];
    char * user;
    char * pass;

    f = fopen("/home/leafy/Retele/WeatherMonitor/login","r");
    if (f == NULL) {
        perror ("Eroare la deschiderea fisierului.\n");
        return errno;
    }

    while (( getline(&line, &length, f)) != EOF ) {
        user = strtok(line," ");
        pass = strtok(NULL," ");
        if (strcmp(user,username) == 0 && strcmp(pass, password) == 10) return 1;
        /* VERIFICARI
         * printf("Line %d : %s", count, line);
         * count+=1;
         * printf("Username : %s ", user);
         * printf("Password: %s ", pass);
         * printf("l_u, %zu , l_p , %zu",strlen(user),strlen(pass));
         * printf("Verif : %d %d \n",strcmp(user,username),strcmp(pass, password));
         *
    }
    fclose(f);
    return 0;
}*/

int addTown(char * user, char * town){

    FILE * f = NULL;
    FILE * f2 = NULL;
    char * line = NULL;
    char * line2 = NULL;
    size_t length = 0;
    size_t length2 = 0;
    char path[100];
    int flag1 = 0, flag2 = 0;

    bzero(path,100);
    strcat(path,"/home/leafy/Retele/WeatherMonitor/userfiles/");
    strcat(path,user);

    f = fopen(path,"r+");
    if (f == NULL) {
        perror ("Eroare la deschiderea fisierului.\n");
        return errno;
    }

    f2 = fopen("/home/leafy/Retele/WeatherMonitor/cities/index","r");
    if (f2 == NULL) {
        perror ("Eroare la deschiderea fisierului.\n");
        return errno;
    }

    while (( getline(&line, &length, f)) != EOF ) {
        line[strcspn(line, "\r\n")] = 0;
        if(strcmp(town,line)==0) flag1 = 1;
    }

    while (( getline(&line2, &length2, f2)) != EOF ) {
        line2[strcspn(line2, "\r\n")] = 0;
        if(strcmp(town,line2)==0) flag2 = 1;
    }

    if(flag2 == 0) return 0;

    if(flag1 == 0) fprintf(f,"%s\n",town);

    fclose(f);
    fclose(f2);
    return 1;
}

int eraseTown(char * user, char * town){
    FILE * f = NULL;
    FILE * f2 = NULL;
    char * line = NULL;
    char * line2 = NULL;
    size_t length = 0;
    size_t length2 = 0;
    char path[100];
    char buffer[500]=" ";

    bzero(path,100);
    strcat(path,"/home/leafy/Retele/WeatherMonitor/userfiles/");
    strcat(path,user);

    f = fopen(path,"r");
    if (f == NULL) {
        perror ("Eroare la deschiderea fisierului.\n");
        return errno;
    }

    f2 = fopen("/home/leafy/Retele/WeatherMonitor/cities/index","r");
    if (f2 == NULL) {
        perror ("Eroare la deschiderea fisierului.\n");
        return errno;
    }

    bzero(buffer,500);
    while(getline(&line,&length,f)!=EOF){
        line[strcspn(line, "\r\n")] = 0;
        if(strcmp(town,line)!=0) {
            strcat(buffer,line);
            strcat(buffer,"\n");
        }
    }

    fclose(f);

    f = fopen(path,"w");
    if (f == NULL) {
        perror ("Eroare la deschiderea fisierului.\n");
        return errno;
    }

    fprintf(f,"%s",buffer);

    fclose(f);
    fclose(f2);
    return 1;
}


char * showWeather(char * user, char * buffer){
    
    FILE *f;
    char * line;
    size_t length;
    char path[100];
    int j = 0, count = 0;
    

    bzero(path,100);
    strcat(path,"/home/leafy/Retele/WeatherMonitor/userfiles/");
    strcat(path,user);

    f = fopen(path,"r");
    
    while(getline(&line,&length,f)!=EOF){
        count++;
    }

    char vect[count][10];

	for (int i = 0; i<count; i++) {
		bzero(vect[i], 10);
	}

	rewind(f);
	while (getline(&line, &length, f) != EOF) {
		line = strtok(line, "\n");
		strcpy(vect[j], line);
		j++;
	}

    /*for(int i=0;i<count;i++){
		printf("%s\n",vect[i]);
	}PANA AICI MERGE*/
    fclose(f);

    for(int i =0; i<count; i++){
        FILE *f2;
        char * line2;
        size_t length2;
        char path2[100];

        bzero(path2,100);
        strcat(path2,"/home/leafy/Retele/WeatherMonitor/cities/");
        strcat(path2,vect[i]);
        //printf("%s\n",path2);
        f2 = fopen(path2,"r");
        
        
        while(getline(&line2,&length2,f2)!=EOF){
            //printf("%s",line2);
            //line = strtok(line, "\n");
            strcat(buffer,line2);            
        }
        if(i!=count-1) strcat(buffer,"\n");
        fclose(f2);
       // printf("===%s",buffer);
    }
    //printf("%s",buffer);
    return buffer;
}

int main(){
    char buffer[1000];
    bzero(buffer,1000);
    //printf("%s",showWeather("root", buffer));
    printf("%s",showWeather("root",buffer));
    //printf("%s",buffer);
    /*printf("===");
    //showWeather("root");
    char vect[1000][1000];
    for (int i = 0; i<1000; i++) {
		bzero(vect[i], 1000);
	}
    sleep(3);
    system("clear");
    char * token1;
    char * tokenN;
    token1 = strtok(buffer,"&");
    tokenN = strtok(NULL,"&");
    printf("%s\n",token1);
    sleep(2);
    system("clear");
    while(tokenN!=NULL){
        printf("%s\n",tokenN);
        tokenN = strtok(NULL,"&");
        sleep(2);
        system("clear");
    }*/
}
