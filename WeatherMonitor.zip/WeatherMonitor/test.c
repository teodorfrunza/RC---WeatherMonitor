#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define PORT 2031

extern int errno;
/*
int verif(char * username, char * password){
    FILE * f = NULL;
    char * line = NULL;
    size_t length = 0;
    int count = 1;
    char vect[2];
    char * user;
    char * pass;

    f = fopen("/home/leafy/Retele/WeatherMonitor/login","r");
    if (f == NULL) {
        perror ("Eroare la deschiderea fisierului.\n");
        return errno;
    }

    while (( getline(&line, &length, f)) != EOF ) {
        user = strtok(line," ");
        pass = strtok(NULL," ");
        if (strcmp(user,username) == 0 && strcmp(pass, password) == 10) return 1;
        /* VERIFICARI
         * printf("Line %d : %s", count, line);
         * count+=1;
         * printf("Username : %s ", user);
         * printf("Password: %s ", pass);
         * printf("l_u, %zu , l_p , %zu",strlen(user),strlen(pass));
         * printf("Verif : %d %d \n",strcmp(user,username),strcmp(pass, password));
         *
    }
    fclose(f);
    return 0;
}*/

int addTown(char * user, char * town){

    FILE * f = NULL;
    FILE * f2 = NULL;
    char * line = NULL;
    char * line2 = NULL;
    size_t length = 0;
    size_t length2 = 0;
    char path[100];
    int flag1 = 0, flag2 = 0;

    bzero(path,100);
    strcat(path,"/home/leafy/Retele/WeatherMonitor/userfiles/");
    strcat(path,user);

    f = fopen(path,"r+");
    if (f == NULL) {
        perror ("Eroare la deschiderea fisierului.\n");
        return errno;
    }

    f2 = fopen("/home/leafy/Retele/WeatherMonitor/cities/index","r");
    if (f2 == NULL) {
        perror ("Eroare la deschiderea fisierului.\n");
        return errno;
    }

    while (( getline(&line, &length, f)) != EOF ) {
        line[strcspn(line, "\r\n")] = 0;
        if(strcmp(town,line)==0) flag1 = 1;
    }

    while (( getline(&line2, &length2, f2)) != EOF ) {
        line2[strcspn(line2, "\r\n")] = 0;
        if(strcmp(town,line2)==0) flag2 = 1;
    }

    if(flag2 == 0) return 0;

    if(flag1 == 0) fprintf(f,"%s\n",town);

    fclose(f);
    fclose(f2);
    return 1;
}

int main(){
    //printf("%d",addTown("root","London"));
    /*
    int j=0;
    int count = 0;
    char * line = NULL;
    size_t length = 0;
    

    FILE *f;
    f = fopen("/home/leafy/Retele/WeatherMonitor/cities/index","r");

    while(getline(&line,&length, f)!=EOF){
        count++;
    }
    //printf("%d",count);

    char vect[count][10];
    
    for(int i=0;i<count;i++){
        bzero(vect[i],10);
    }
    
    rewind(f);
    while(getline(&line, &length, f)!=EOF){
        line = strtok(line,"\n");
        strcpy(vect[j],line);
        j++;
    }
    
    char addMenu[100]= " ";
    char nr[2];
    
    bzero(addMenu,100);
   

    for(int i=0;i<count;i++){
        bzero(nr,2);
        snprintf(nr,sizeof(nr),"%d",i); //conversie pentru strcat a int spre char
        strcat(addMenu,nr);
        strcat(addMenu,".");
        strcat(addMenu,vect[i]);
        strcat(addMenu,"\n");
    }
    strcat(addMenu,"Please select one of the above: ");
    printf("%s",addMenu);

    /*for(int i=0;i<count;i++){
        printf("%s\n",vect[i]);
    }*/
    //fclose(f);
    char asd[100];
    bzero(asd,100);
    read(0,asd,100);
    int a = atoi(asd);
    printf("%d",a);
}
