Aplicatia WeatheMonitor este alcatuita din 2 server concurente si un client. La accesarea serverului pentru client va aparea un meniu de login ce va necesita un nume si parola separate prin spatiu exemplu root toor. Daca acestea sunt corecte se va avansa la urmatorul meniu. In caz contrar se va inchide conexiunea. Exista si o optiune de register cu aceleasi conditii pentru input. Dupa login va aparea un meniu cu 4 optiuni show weather/add town/remove town/exit.
La alegerea oricarei optiuni se va deschide un nou meniu. pentru show weather se va afisa vremea pentru orasele salvate in fisierul clientului . La apasarea oricarei taste+enter se va face refresh. In al doilea meniu (add town) clientul paote adauga orase in lsita lui de preferinta. In al 3-lea meniu le poate sterge. q este tasta universala de back si x de quit. La serverul adminului nu se mai face conectare cu login si ii apare direct meniul de modificare date meteo aduagare orase sau stergere orase. Adaugarea si stergerea creaza/sterg fisiere cu orase iar modificarea atribuie date. 





Bibliografie

http://man7.org/linux/man-pages/man3/getline.3.html
http://man7.org/linux/man-pages/man3/printf.3.html
https://stackoverflow.com/questions/3889992/how-does-strtok-split-the-string-into-tokens-in-c
https://stackoverflow.com/questions/11793689/read-the-entire-contents-of-a-file-to-c-char-including-new-lines
https://overiq.com/c-programming/101/array-of-strings-in-c/
https://stackoverflow.com/questions/29397719/c-getline-and-strcmp-issue
https://stackoverflow.com/questions/13004195/c-make-variable-int-as-char-for-strcat
http://www.cplusplus.com/reference/cstdio/snprintf/
