#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int addTown(char * user, char * town) {

	FILE * f = NULL;
	FILE * f2 = NULL;
	char * line = NULL;
	char * line2 = NULL;
	size_t length = 0;
	size_t length2 = 0;
	char path[1000];
    char buffer[1000];
    bzero(buffer,1000);
	int flag1 = 0, flag2 = 0,c=0;

	bzero(path,100);
    strcat(path,"/home/leafy/Retele/WeatherMonitor/userfiles/");
    strcat(path,user);
    
    f = fopen(path,"r");
    while(getline(&line,&length,f)!=EOF){
        if(strcmp(line,town)==0) flag1 =1;
    }
    
    if(flag1 == 1) return 0;
    else{
        rewind(f);

        while(getline(&line,&length,f)!=EOF){
           if(strcmp(line,"nimic")!=0) {
                strcat(buffer,line);
                strcat(buffer,"\n");
            }
            
        }

        
    }
    //printf("%s",buffer);
    strcat(buffer,town);
    printf("%s",buffer);
    fclose(f);
    f = fopen(path,"w");
    fprintf(f,"%s",buffer);
    fclose(f);
}

int main(){
    addTown("root","asc");
}

